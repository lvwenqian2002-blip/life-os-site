const WECHAT_URL = "https://wx.qq.com/";
const ALARM_NAME = "life-os-browser-wechat-poll";
const NATIVE_HOST = "com.lifeos.wechat_bridge";

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(ALARM_NAME, { periodInMinutes: 1 });
});
chrome.runtime.onStartup.addListener(() => chrome.alarms.create(ALARM_NAME, { periodInMinutes: 1 }));
chrome.alarms.onAlarm.addListener((alarm) => { if (alarm.name === ALARM_NAME) void pollDueReminders(); });

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== "LIFE_OS_EXTENSION_REQUEST") return false;
  void handleRequest(message.action, message.payload).then(
    (data) => sendResponse({ ok: true, data }),
    (error) => sendResponse({ ok: false, error: error instanceof Error ? error.message : "插件操作失败" }),
  );
  return true;
});

async function handleRequest(action, payload = {}) {
  if (action === "GET_STATUS") return getCombinedStatus();
  if (action === "OPEN_WECHAT") return openWechat();
  if (action === "OPEN_NEW_WECHAT") return openNewWechat();
  if (action === "PAIR_DEVICE") return pairDevice(payload);
  if (action === "SEND_CONFIRMED_MESSAGE") {
    if (payload.confirmation !== true) throw new Error("发送前必须明确确认");
    return sendWechatMessage(payload.contactAlias, payload.content, true);
  }
  if (action === "POLL_NOW") return pollDueReminders();
  if (action === "GET_WECHAT_VIEW") return getWechatView();
  if (action === "CAPTURE_WECHAT_VIEW") return captureWechatView();
  if (action === "GET_DESKTOP_STATUS") return getDesktopStatus();
  if (action === "CAPTURE_DESKTOP_WECHAT") return nativeRequest({ action: "capture_chat" });
  if (action === "DESKTOP_SEND_CONFIRMED") {
    if (payload.confirmation !== true) throw new Error("发送前必须明确确认");
    return nativeRequest({ action: "send_message", contactAlias: String(payload.contactAlias || ""), content: String(payload.content || ""), confirmation: true });
  }
  if (action === "DESKTOP_PREPARE_FRIEND") {
    if (payload.confirmation !== true) throw new Error("准备好友操作前必须明确确认");
    return nativeRequest({ action: "prepare_friend", contactAlias: String(payload.contactAlias || ""), note: String(payload.note || ""), confirmation: true });
  }
  throw new Error("不支持的插件操作");
}

async function getDesktopStatus() {
  try { return await nativeRequest({ action: "status" }); }
  catch (error) { return { hostInstalled: false, wechatDetected: false, captureAvailable: false, rpaAvailable: false, safetyMode: "confirm_each_action", message: error instanceof Error ? error.message : "本地助手未安装" }; }
}

function nativeRequest(payload) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendNativeMessage(NATIVE_HOST, payload, (response) => {
      const error = chrome.runtime.lastError?.message;
      if (error) reject(new Error(`桌面助手不可用：${error}`));
      else if (!response?.ok) reject(new Error(response?.error || "桌面助手操作失败"));
      else resolve(response.data);
    });
  });
}

async function getWechatView() {
  const tab = await findWechatTab();
  if (!tab?.id) throw new Error("微信网页版未打开");
  return chrome.tabs.sendMessage(tab.id, { type: "LIFE_OS_WECHAT_VIEW" });
}

async function captureWechatView() {
  const tab = await findWechatTab();
  if (!tab?.id || tab.windowId === undefined) throw new Error("微信网页版未打开");
  const [previous] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  await chrome.tabs.update(tab.id, { active: true });
  await new Promise((resolve) => setTimeout(resolve, 250));
  const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" });
  if (previous?.id && previous.id !== tab.id) await chrome.tabs.update(previous.id, { active: true });
  return { dataUrl };
}

async function pairDevice(payload) {
  const apiBaseUrl = String(payload.apiBaseUrl || "").replace(/\/$/, "");
  const deviceToken = String(payload.deviceToken || "");
  if (!apiBaseUrl.startsWith("https://") || deviceToken.length < 32) throw new Error("配对信息无效");
  const previous = await chrome.storage.local.get("lifeOsPairing");
  await chrome.storage.local.set({ lifeOsPairing: { apiBaseUrl, deviceToken, deviceName: String(payload.deviceName || "Chrome 插件"), pairedAt: new Date().toISOString() } });
  try { await deviceRequest("/browser-wechat/device/heartbeat", { method: "POST", body: "{}" }); }
  catch (error) { if (previous.lifeOsPairing) await chrome.storage.local.set({ lifeOsPairing: previous.lifeOsPairing }); else await chrome.storage.local.remove("lifeOsPairing"); throw error; }
  return getCombinedStatus();
}

async function getCombinedStatus() {
  const { lifeOsPairing } = await chrome.storage.local.get("lifeOsPairing");
  const tab = await findWechatTab();
  let wechat = { tabOpen: false, loggedIn: false, qrUrl: null };
  if (tab?.id) {
    try { wechat = { tabOpen: true, ...(await chrome.tabs.sendMessage(tab.id, { type: "LIFE_OS_WECHAT_STATUS" })) }; }
    catch { wechat = { tabOpen: true, loggedIn: false, qrUrl: null }; }
  }
  return { installed: true, paired: Boolean(lifeOsPairing?.deviceToken), pairing: lifeOsPairing ? { deviceName: lifeOsPairing.deviceName || "Chrome 插件", apiBaseUrl: lifeOsPairing.apiBaseUrl, pairedAt: lifeOsPairing.pairedAt || null } : null, wechat };
}

async function openWechat() {
  let tab = await findWechatTab();
  if (!tab) tab = await chrome.tabs.create({ url: WECHAT_URL, active: true });
  else if (tab.id) await chrome.tabs.update(tab.id, { active: true });
  return { opened: true, tabId: tab.id };
}

async function openNewWechat() {
  const tab = await chrome.tabs.create({ url: `${WECHAT_URL}?lang=zh_CN&life_os_switch=${Date.now()}`, active: true });
  return { opened: true, tabId: tab.id, newTab: true };
}

async function findWechatTab() {
  const tabs = await chrome.tabs.query({ url: ["https://wx.qq.com/*", "https://wx2.qq.com/*", "https://wx8.qq.com/*", "https://web.wechat.com/*"] });
  return tabs.find((tab) => tab.active) || tabs.at(-1) || null;
}

async function sendWechatMessage(contactAlias, content, authorized) {
  if (!contactAlias || !content || authorized !== true) throw new Error("联系人、消息或确认信息不完整");
  const tab = await findWechatTab();
  if (!tab?.id) throw new Error("微信网页版未打开");
  const status = await chrome.tabs.sendMessage(tab.id, { type: "LIFE_OS_WECHAT_STATUS" });
  if (!status?.loggedIn) throw new Error("微信网页版尚未扫码登录");
  const result = await chrome.tabs.sendMessage(tab.id, { type: "LIFE_OS_WECHAT_SEND", contactAlias, content, authorized: true });
  if (!result?.sent) throw new Error(result?.error || "微信网页未确认发送成功");
  return result;
}

async function pollDueReminders() {
  const { lifeOsPairing } = await chrome.storage.local.get("lifeOsPairing");
  if (!lifeOsPairing?.deviceToken) return { paired: false, sent: 0 };
  await deviceRequest("/browser-wechat/device/heartbeat", { method: "POST", body: "{}" });
  const tab = await findWechatTab();
  let status = null;
  if (tab?.id) {
    try { status = await chrome.tabs.sendMessage(tab.id, { type: "LIFE_OS_WECHAT_STATUS" }); } catch { status = null; }
  }
  const desktop = await getDesktopStatus();
  if (!status?.loggedIn && !desktop.wechatDetected) return { paired: true, loggedIn: false, desktopDetected: false, sent: 0 };
  const reminders = await deviceRequest("/browser-wechat/device/reminders/due");
  let sent = 0;
  for (const reminder of reminders) {
    try {
      if (status?.loggedIn) await sendWechatMessage(reminder.contactAlias, reminder.content, true);
      else await nativeRequest({ action: "send_message", contactAlias: reminder.contactAlias, content: reminder.content, confirmation: true, source: "confirmed_scheduled_reminder" });
      await acknowledge(reminder.id, "SENT");
      sent += 1;
    } catch (error) {
      await acknowledge(reminder.id, "FAILED", error instanceof Error ? error.message : "发送失败");
      await notify("Life OS 微信提醒发送失败", `${reminder.taskTitle}：${error instanceof Error ? error.message : "发送失败"}`);
    }
  }
  return { paired: true, loggedIn: Boolean(status?.loggedIn), desktopDetected: Boolean(desktop.wechatDetected), sent };
}

async function acknowledge(id, status, error) {
  return deviceRequest(`/browser-wechat/device/reminders/${encodeURIComponent(id)}/ack`, { method: "POST", body: JSON.stringify({ status, ...(error ? { error } : {}) }) });
}

async function deviceRequest(path, options = {}) {
  const { lifeOsPairing } = await chrome.storage.local.get("lifeOsPairing");
  if (!lifeOsPairing?.deviceToken) throw new Error("插件尚未与 Life OS 配对");
  const response = await fetch(`${lifeOsPairing.apiBaseUrl}${path}`, { ...options, headers: { "Content-Type": "application/json", Authorization: `Device ${lifeOsPairing.deviceToken}`, ...options.headers } });
  const body = await response.json().catch(() => null);
  if (!response.ok) throw new Error(Array.isArray(body?.message) ? body.message.join("；") : body?.message || `服务响应 ${response.status}`);
  return body?.data;
}

async function notify(title, message) {
  try { await chrome.notifications.create({ type: "basic", iconUrl: chrome.runtime.getURL("icon.svg"), title, message }); } catch {}
}

void pollDueReminders().catch(() => undefined);
