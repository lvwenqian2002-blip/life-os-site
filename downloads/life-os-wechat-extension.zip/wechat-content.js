const SEARCH_SELECTORS = ["#search_bar input", "input[placeholder*='搜索']", ".frm_search"];
const EDITOR_SELECTORS = ["#editArea", ".edit_area[contenteditable='true']", "[contenteditable='true'][ng-model*='editArea']"];
const SEND_SELECTORS = [".btn_send", "button[ng-click*='sendTextMessage']", "button[type='submit']"];

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "LIFE_OS_WECHAT_STATUS") { sendResponse(readStatus()); return false; }
  if (message?.type === "LIFE_OS_WECHAT_VIEW") { sendResponse(readView()); return false; }
  if (message?.type === "LIFE_OS_WECHAT_SEND") {
    void sendMessage(message).then(sendResponse, (error) => sendResponse({ sent: false, error: error instanceof Error ? error.message : "发送失败" }));
    return true;
  }
  return false;
});

function readStatus() {
  const qr = document.querySelector(".qrcode img, img.qrcode, [class*='qrcode'] img");
  const editor = findFirst(EDITOR_SELECTORS);
  const chatShell = document.querySelector(".chat_list, .chat_item, #chatArea, [ng-controller*='chat']");
  return { loggedIn: Boolean(editor || chatShell) && !qr, qrUrl: qr instanceof HTMLImageElement ? new URL(qr.src, location.href).href : null, pageTitle: document.title };
}

function readView() {
  const status = readStatus();
  if (!status.loggedIn) return { ...status, contacts: [], activeContact: "", messages: [] };
  const contactNodes = [...document.querySelectorAll(".chat_item, .contact_item, [ng-repeat*='chatContact'], [mm-repeat*='chatContact']")].slice(0, 40);
  const contacts = contactNodes.map((node, index) => ({
    id: String(index), name: clean(node.querySelector(".nickname, .nickname_text, h3, .title")?.textContent || node.textContent || "未知联系人", 60),
    preview: clean(node.querySelector(".msg, .desc, .info")?.textContent || "", 100), active: node.classList.contains("active") || node.classList.contains("current"),
  })).filter((item) => item.name);
  const activeContact = clean(document.querySelector("#chatArea .title_name, .chat_bd .title, .chat_header .nickname")?.textContent || contacts.find((item) => item.active)?.name || "当前会话", 60);
  const messageNodes = [...document.querySelectorAll("#chatArea .message, .chat_bd .message, .message")].slice(-40);
  const messages = messageNodes.map((node, index) => ({ id: String(index), fromMe: node.classList.contains("me") || Boolean(node.closest(".me")), text: clean(node.querySelector(".bubble, .plain, .content")?.textContent || node.textContent || "", 1000) })).filter((item) => item.text);
  return { ...status, contacts, activeContact, messages, capturedAt: new Date().toISOString() };
}

function clean(value, max) { return String(value).replace(/\s+/g, " ").trim().slice(0, max); }

async function sendMessage({ contactAlias, content, authorized }) {
  if (authorized !== true) throw new Error("消息尚未确认");
  if (!readStatus().loggedIn) throw new Error("微信网页版尚未扫码登录");
  const search = findFirst(SEARCH_SELECTORS);
  if (!search) throw new Error("没有找到微信联系人搜索框，请刷新微信网页版");
  setValue(search, String(contactAlias));
  await wait(900);
  const candidates = [...document.querySelectorAll(".contact_item, .search_item, .chat_item, [ng-repeat*='contact'], [mm-repeat*='contact']")];
  const target = candidates.find((element) => (element.textContent || "").trim().includes(String(contactAlias).trim()));
  if (!target) throw new Error(`没有找到联系人“${contactAlias}”`);
  target.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, view: window }));
  await wait(700);
  const editor = findFirst(EDITOR_SELECTORS);
  if (!editor) throw new Error("没有找到微信消息输入框");
  editor.focus();
  if (editor instanceof HTMLInputElement || editor instanceof HTMLTextAreaElement) setValue(editor, String(content));
  else { editor.textContent = String(content); editor.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: String(content) })); }
  await wait(150);
  const button = findFirst(SEND_SELECTORS);
  if (button) button.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, view: window }));
  else editor.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", keyCode: 13, bubbles: true }));
  await wait(350);
  return { sent: true, contactAlias: String(contactAlias) };
}

function findFirst(selectors) { for (const selector of selectors) { const element = document.querySelector(selector); if (element instanceof HTMLElement) return element; } return null; }
function setValue(element, value) { const prototype = element instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype; const setter = Object.getOwnPropertyDescriptor(prototype, "value")?.set; if (setter) setter.call(element, value); else element.value = value; element.dispatchEvent(new Event("input", { bubbles: true })); element.dispatchEvent(new Event("change", { bubbles: true })); }
function wait(ms) { return new Promise((resolve) => setTimeout(resolve, ms)); }
