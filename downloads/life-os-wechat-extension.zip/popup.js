const status = document.querySelector("#status");
document.querySelector("#openWechat").addEventListener("click", () => chrome.runtime.sendMessage({ type: "LIFE_OS_EXTENSION_REQUEST", action: "OPEN_WECHAT" }));
document.querySelector("#openLifeOs").addEventListener("click", () => chrome.tabs.create({ url: "https://lvwenqian2002-blip.github.io/life-os-site/" }));
chrome.runtime.sendMessage({ type: "LIFE_OS_EXTENSION_REQUEST", action: "GET_STATUS" }, (response) => {
  if (!response?.ok) { status.textContent = response?.error || "状态读取失败"; return; }
  const data = response.data;
  status.innerHTML = `<b>${data.paired ? "已与 Life OS 配对" : "等待网站配对"}</b><span>${data.wechat.loggedIn ? "微信网页版已登录" : data.wechat.tabOpen ? "等待微信扫码" : "微信网页未打开"}</span>`;
});
