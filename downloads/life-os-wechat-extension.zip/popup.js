const status = document.querySelector("#status");
document.querySelector("#openLifeOs").addEventListener("click", () => chrome.tabs.create({ url: "https://lvwenqian2002-blip.github.io/life-os-site/" }));
document.querySelector("#refresh").addEventListener("click", check);
function check() {
  status.textContent = "正在检查本地连接…";
  chrome.runtime.sendMessage({ type: "LIFE_OS_EXTENSION_REQUEST", action: "GET_STATUS" }, (response) => {
    if (!response?.ok) { status.textContent = response?.error || "状态读取失败"; return; }
    const data = response.data;
    chrome.runtime.sendMessage({ type: "LIFE_OS_EXTENSION_REQUEST", action: "GET_DESKTOP_STATUS" }, (desktopResponse) => {
      const desktop = desktopResponse?.data;
      status.innerHTML = `<b>${data.paired ? "已与 Life OS 配对" : "等待网站配对"}</b><span>${desktop?.wechatDetected ? "Life OS 助手已识别 Windows 微信" : desktop?.hostInstalled ? "请打开并登录 Windows 微信" : "请安装 Life OS Windows 助手"}</span>`;
    });
  });
}
check();
