window.addEventListener("message", (event) => {
  if (event.source !== window || event.data?.source !== "LIFE_OS_WEB" || !event.data?.requestId) return;
  chrome.runtime.sendMessage({ type: "LIFE_OS_EXTENSION_REQUEST", action: event.data.action, payload: event.data.payload || {} }, (response) => {
    const error = chrome.runtime.lastError?.message;
    window.postMessage({ source: "LIFE_OS_EXTENSION", requestId: event.data.requestId, ok: Boolean(response?.ok) && !error, data: response?.data, error: error || response?.error }, window.location.origin);
  });
});
window.postMessage({ source: "LIFE_OS_EXTENSION", type: "READY" }, window.location.origin);
