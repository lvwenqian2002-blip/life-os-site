$ErrorActionPreference = 'Stop'
$registryPath = 'HKCU:\Software\Google\Chrome\NativeMessagingHosts\com.lifeos.wechat_bridge'
if (Test-Path -LiteralPath $registryPath) { Remove-Item -LiteralPath $registryPath -Recurse -Force }
Write-Host 'Life OS 微信桌面助手已从 Chrome 注销。文件仍保留，可重新安装。' -ForegroundColor Yellow
