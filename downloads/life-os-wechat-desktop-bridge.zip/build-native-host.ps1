$ErrorActionPreference = 'Stop'
$bridgeRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$sourcePath = Join-Path $bridgeRoot 'LifeOsWechatBridge.cs'
$binaryPath = Join-Path $bridgeRoot 'LifeOS-WeChat-Assistant.exe'

if (Test-Path -LiteralPath $binaryPath) { Remove-Item -LiteralPath $binaryPath -Force }
Add-Type -TypeDefinition (Get-Content -Raw -Encoding UTF8 -LiteralPath $sourcePath) -Language CSharp -OutputAssembly $binaryPath -OutputType WindowsApplication -ReferencedAssemblies @(
  'System.dll',
  'System.Drawing.dll',
  'System.Web.Extensions.dll',
  'System.Windows.Forms.dll'
)

if (-not (Test-Path -LiteralPath $binaryPath)) { throw 'Windows EXE 生成失败' }
Write-Output "Life OS 微信桌面助手 EXE：$binaryPath"
