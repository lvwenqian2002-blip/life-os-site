param(
  [Parameter(Mandatory = $true)]
  [ValidatePattern('^[a-p]{32}$')]
  [string]$ExtensionId
)

$ErrorActionPreference = 'Stop'
$bridgeRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$sourcePath = Join-Path $bridgeRoot 'LifeOsWechatBridge.cs'
$binaryPath = Join-Path $bridgeRoot 'LifeOsWechatBridge.exe'
$manifestPath = Join-Path $bridgeRoot 'com.lifeos.wechat_bridge.json'

if (Test-Path -LiteralPath $binaryPath) { Remove-Item -LiteralPath $binaryPath -Force }
Add-Type -TypeDefinition (Get-Content -Raw -Encoding UTF8 -LiteralPath $sourcePath) -Language CSharp -OutputAssembly $binaryPath -OutputType ConsoleApplication -ReferencedAssemblies @(
  'System.dll',
  'System.Drawing.dll',
  'System.Web.Extensions.dll',
  'System.Windows.Forms.dll'
)

$manifest = [ordered]@{
  name = 'com.lifeos.wechat_bridge'
  description = 'Life OS Windows WeChat desktop bridge'
  path = $binaryPath
  type = 'stdio'
  allowed_origins = @("chrome-extension://$ExtensionId/")
}
$manifest | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $manifestPath -Encoding UTF8

$registryPath = 'HKCU:\Software\Google\Chrome\NativeMessagingHosts\com.lifeos.wechat_bridge'
New-Item -Path $registryPath -Force | Out-Null
Set-Item -Path $registryPath -Value $manifestPath

Write-Host 'Life OS 微信桌面助手已安装。请完全退出并重新打开 Chrome，然后在网站点击“刷新状态”。' -ForegroundColor Green
