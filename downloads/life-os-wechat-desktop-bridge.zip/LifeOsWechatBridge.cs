using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;

internal static class LifeOsWechatBridge
{
    private static readonly JavaScriptSerializer Json = new JavaScriptSerializer();
    private static readonly string[] WechatProcesses = { "Weixin", "WeChat", "WeChatAppEx" };

    [StructLayout(LayoutKind.Sequential)]
    private struct Rect { public int Left; public int Top; public int Right; public int Bottom; }

    [DllImport("user32.dll")] private static extern bool SetForegroundWindow(IntPtr hWnd);
    [DllImport("user32.dll")] private static extern bool ShowWindow(IntPtr hWnd, int command);
    [DllImport("user32.dll")] private static extern bool GetWindowRect(IntPtr hWnd, out Rect rect);

    [STAThread]
    private static void Main()
    {
        Console.InputEncoding = Encoding.UTF8;
        Console.OutputEncoding = Encoding.UTF8;
        Stream input = Console.OpenStandardInput();
        Stream output = Console.OpenStandardOutput();
        while (true)
        {
            byte[] header = ReadExact(input, 4);
            if (header == null) break;
            int length = BitConverter.ToInt32(header, 0);
            if (length <= 0 || length > 8 * 1024 * 1024) { Write(output, Error("消息长度无效")); continue; }
            byte[] body = ReadExact(input, length);
            if (body == null) break;
            try
            {
                Dictionary<string, object> request = Json.Deserialize<Dictionary<string, object>>(Encoding.UTF8.GetString(body));
                Write(output, Handle(request));
            }
            catch (Exception error) { Write(output, Error(error.Message)); }
        }
    }

    private static Dictionary<string, object> Handle(Dictionary<string, object> request)
    {
        string action = Text(request, "action");
        if (action == "status") return Ok(Status());
        if (action == "capture_chat") return Ok(CaptureWechat());
        if (action == "send_message")
        {
            RequireConfirmation(request);
            return Ok(SendMessage(Text(request, "contactAlias"), Text(request, "content")));
        }
        if (action == "prepare_friend")
        {
            RequireConfirmation(request);
            return Ok(PrepareFriend(Text(request, "contactAlias"), Text(request, "note")));
        }
        throw new InvalidOperationException("不支持的桌面操作");
    }

    private static Dictionary<string, object> Status()
    {
        Process process = FindWechat();
        return new Dictionary<string, object> {
            { "hostInstalled", true },
            { "wechatDetected", process != null },
            { "processName", process == null ? "" : process.ProcessName },
            { "processId", process == null ? 0 : process.Id },
            { "windowTitle", process == null ? "" : process.MainWindowTitle },
            { "captureAvailable", process != null },
            { "rpaAvailable", process != null },
            { "safetyMode", "confirm_each_action" },
            { "message", process == null ? "未检测到电脑微信，请先打开并登录 Windows 微信。" : "已检测到电脑微信；截图、提醒和回复均需由 Life OS 中的明确确认触发。" }
        };
    }

    private static Dictionary<string, object> CaptureWechat()
    {
        Process process = RequireWechat();
        Rect rect;
        if (!GetWindowRect(process.MainWindowHandle, out rect)) throw new InvalidOperationException("无法读取微信窗口位置");
        int width = rect.Right - rect.Left;
        int height = rect.Bottom - rect.Top;
        if (width < 200 || height < 200) throw new InvalidOperationException("微信窗口未显示，请先恢复窗口");
        using (Bitmap bitmap = new Bitmap(width, height))
        using (Graphics graphics = Graphics.FromImage(bitmap))
        using (MemoryStream stream = new MemoryStream())
        {
            graphics.CopyFromScreen(rect.Left, rect.Top, 0, 0, new Size(width, height));
            bitmap.Save(stream, ImageFormat.Png);
            return new Dictionary<string, object> {
                { "dataUrl", "data:image/png;base64," + Convert.ToBase64String(stream.ToArray()) },
                { "capturedAt", DateTime.UtcNow.ToString("o") },
                { "windowTitle", process.MainWindowTitle },
                { "imageRetained", false }
            };
        }
    }

    private static Dictionary<string, object> SendMessage(string contactAlias, string content)
    {
        if (String.IsNullOrWhiteSpace(contactAlias) || contactAlias.Length > 100) throw new InvalidOperationException("联系人备注或昵称无效");
        if (String.IsNullOrWhiteSpace(content) || content.Length > 4000) throw new InvalidOperationException("消息内容无效或过长");
        Process process = RequireWechat();
        Focus(process);
        SendKeys.SendWait("^f");
        Thread.Sleep(450);
        Paste(contactAlias);
        Thread.Sleep(650);
        SendKeys.SendWait("{ENTER}");
        Thread.Sleep(650);
        Paste(content);
        Thread.Sleep(250);
        SendKeys.SendWait("{ENTER}");
        return new Dictionary<string, object> { { "sent", true }, { "contactAlias", contactAlias }, { "confirmed", true }, { "sentAt", DateTime.UtcNow.ToString("o") } };
    }

    private static Dictionary<string, object> PrepareFriend(string contactAlias, string note)
    {
        if (String.IsNullOrWhiteSpace(contactAlias)) throw new InvalidOperationException("请输入好友微信号、手机号或备注");
        Process process = RequireWechat();
        Focus(process);
        Paste(String.IsNullOrWhiteSpace(note) ? contactAlias : contactAlias + Environment.NewLine + note);
        return new Dictionary<string, object> {
            { "prepared", true },
            { "confirmationRequired", true },
            { "message", "已打开电脑微信并把好友信息复制到剪贴板。由于不同微信版本的加好友入口不一致，请由你粘贴并完成最后确认。" }
        };
    }

    private static void Focus(Process process)
    {
        ShowWindow(process.MainWindowHandle, 9);
        if (!SetForegroundWindow(process.MainWindowHandle)) throw new InvalidOperationException("无法激活微信窗口，请先手动点击微信后重试");
        Thread.Sleep(350);
    }

    private static void Paste(string value)
    {
        Exception last = null;
        for (int attempt = 0; attempt < 5; attempt++)
        {
            try { Clipboard.SetText(value); SendKeys.SendWait("^v"); return; }
            catch (Exception error) { last = error; Thread.Sleep(120); }
        }
        throw new InvalidOperationException("无法写入剪贴板：" + (last == null ? "未知错误" : last.Message));
    }

    private static Process RequireWechat()
    {
        Process process = FindWechat();
        if (process == null) throw new InvalidOperationException("未检测到已打开的电脑微信");
        return process;
    }

    private static Process FindWechat()
    {
        foreach (string name in WechatProcesses)
        {
            foreach (Process process in Process.GetProcessesByName(name))
            {
                try { if (process.MainWindowHandle != IntPtr.Zero) return process; }
                catch { }
            }
        }
        return null;
    }

    private static void RequireConfirmation(Dictionary<string, object> request)
    {
        object value;
        if (!request.TryGetValue("confirmation", out value) || !(value is bool) || !(bool)value) throw new InvalidOperationException("此操作需要用户明确确认");
    }

    private static string Text(Dictionary<string, object> request, string key)
    {
        object value;
        return request.TryGetValue(key, out value) && value != null ? Convert.ToString(value) : "";
    }

    private static Dictionary<string, object> Ok(Dictionary<string, object> data) { return new Dictionary<string, object> { { "ok", true }, { "data", data } }; }
    private static Dictionary<string, object> Error(string message) { return new Dictionary<string, object> { { "ok", false }, { "error", message } }; }

    private static byte[] ReadExact(Stream stream, int count)
    {
        byte[] buffer = new byte[count];
        int offset = 0;
        while (offset < count)
        {
            int read = stream.Read(buffer, offset, count - offset);
            if (read <= 0) return null;
            offset += read;
        }
        return buffer;
    }

    private static void Write(Stream output, Dictionary<string, object> response)
    {
        byte[] body = Encoding.UTF8.GetBytes(Json.Serialize(response));
        byte[] header = BitConverter.GetBytes(body.Length);
        output.Write(header, 0, header.Length);
        output.Write(body, 0, body.Length);
        output.Flush();
    }
}
